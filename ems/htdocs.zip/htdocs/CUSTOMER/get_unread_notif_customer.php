<?php
session_start();
header('Content-Type: application/json');

$con = mysqli_connect("localhost", "root", "", "kylies");

if (!isset($_SESSION['Username'])) {
    echo json_encode(['count' => 0]);
    exit;
}

$username = $_SESSION['Username'];

$result = mysqli_query($con, "SELECT COUNT(*) AS count FROM notifcustomer WHERE Username = '$username' AND is_read = 0");
$data = mysqli_fetch_assoc($result);
echo json_encode(['count' => (int)$data['count']]);
?>
