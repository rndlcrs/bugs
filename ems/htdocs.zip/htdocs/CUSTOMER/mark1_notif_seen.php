<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "kylies");

if (!$con || !isset($_SESSION['Username'])) {
    exit;
}

$username = $_SESSION['Username'];
mysqli_query($con, "UPDATE notifcustomer SET is_read = 1 WHERE Username = '$username'");
?>
