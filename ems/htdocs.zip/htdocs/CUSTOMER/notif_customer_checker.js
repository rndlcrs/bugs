// Unlock audio on first interaction
document.addEventListener('click', () => {
    const sound = document.getElementById("notifSound");
    if (sound) sound.play().catch(() => {});
}, { once: true });

let unreadCount = parseInt(document.body.getAttribute('data-initial-unread')) || 0;

function checkCustomerNotif() {
    fetch('get_unread_notif_customer.php')  // you'll create this file
        .then(response => response.json())
        .then(data => {
            const newCount = data.count;
            if (newCount > unreadCount) {
                const sound = document.getElementById("notifSound");
                if (sound) sound.play().catch(() => {});

                const dot = document.querySelector('.notif-dot');
                if (dot) {
                    dot.classList.remove('gray-dot');
                    dot.classList.add('red-dot');
                }

                showCustomerToast("📦 Your order status has been updated!");
                unreadCount = newCount;
            }
        });
}

setInterval(checkCustomerNotif, 60000);
document.addEventListener('DOMContentLoaded', checkCustomerNotif);

// Toast function
function showCustomerToast(message) {
    const toast = document.createElement('div');
    toast.className = 'notif-toast';
    toast.innerText = message;
    document.body.appendChild(toast);

    setTimeout(() => toast.classList.add('show'), 10);
    setTimeout(() => {
        toast.classList.remove('show');
        
    });
}
