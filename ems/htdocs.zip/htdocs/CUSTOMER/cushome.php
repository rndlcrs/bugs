<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "kylies");

// Redirect if not logged in
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

$Username = $_SESSION['Username'];
$notifcustomer = [];
$has_unread = false;

// ✅ Handle status update from admin
if (isset($_POST['update_status'])) {
    $orderId = intval($_POST['order_id']);
    $status = $_POST['status'];

    // Update order status
    $stmt = $con->prepare("UPDATE orders SET Status=? WHERE ID=?");
    $stmt->bind_param("si", $status, $orderId);
    $stmt->execute();
    $stmt->close();

    // Get customer username for this order
    $userResult = mysqli_query($con, "SELECT Username FROM orders WHERE ID = $orderId");
    $user = mysqli_fetch_assoc($userResult)['Username'];

    // Check for duplicate notification
    $checkNotif = mysqli_query($con, "SELECT ID FROM notifcustomer WHERE Username='$user' AND Status='$status' AND Message LIKE '%$orderId%'");
    if (mysqli_num_rows($checkNotif) == 0) {
        $notifMessage = "Your order ID $orderId is now $status.";
        $insertNotif = $con->prepare("INSERT INTO notifcustomer (Username, Message, Status, CreatedAt, is_read) VALUES (?, ?, ?, NOW(), 0)");
        $insertNotif->bind_param("sss", $user, $notifMessage, $status);
        $insertNotif->execute();
        $insertNotif->close();
    }
}

// ✅ Fetch notifications for current user
$notifResult = mysqli_query($con, "SELECT * FROM notifcustomer WHERE Username='$Username' ORDER BY CreatedAt DESC");

if ($notifResult && mysqli_num_rows($notifResult) > 0) {
    while ($row = mysqli_fetch_assoc($notifResult)) {
        $notifcustomer[] = $row;
        if ($row['is_read'] == 0) {
            $has_unread = true;
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="cushome.css">
    <title>CUSTOMER HOME</title>
</head>
<body>
    <!-- Navbar -->
     <nav class="navbar">
        <a href="#" class="logo"><img src="../images/logo.png" alt=""></a>
        <h2>Hi <?= htmlspecialchars($Username); ?>, Welcome to Kylie's!</h2>
        <ul class="nav-links">
            <li class="active"><a href="../CUSTOMER/cushome.php">HOME</a></li>
            <li><a href="../CUSTOMER/custprofile.php">PROFILE</a></li>
            <li><a href="../CUSTOMER/aboutus.html">ABOUT</a></li>
            <li><a href="../CUSTOMER/contacts.php">CONTACT</a></li>
            <li class="ctn"><a href="../CUSTOMER/logout.php">LOGOUT</a></li>
        </ul>

        <img src="../images/menu.png" alt="" class="menu-btn">

        <div class="menu-btn"><i class='bxr  bx-menu-wider'></i> </div>

    </nav>
    <header>
        <div class="header-content">
            <h1>KYLIE'S WATER REFILLING STATION</h1>
            <div class="line"></div>
            <h2>"Stay Hydrated, Reduce Waste: Refill with Us"</h2>
            <a href="../CUSTOMER/order.php" class="ctn">ORDER NOW!</a>
        </div>

        <div class="notif_wrapper">
        <a href="#" onclick="openNotifModal(); return false;">
            <img class="notif_icon" src="../images/notif.png" alt="">
            <span class="notif-dot <?= $has_unread ? 'red-dot' : 'gray-dot' ?>"></span>
        </a>
        </div>


        <!-- Modal (can be hidden by default) -->
        <div id="notifModal" style="display:none;">
            <span class="close-btn" onclick="dismissNotif()">&times;</span>
            <h3>🔔 Order Status Updates</h3>
            <ul>
                <?php foreach ($notifcustomer as $notif): ?>
                    <?php if (isset($notif['message']) && isset($notif['CreatedAt'])): ?>
                        <li class="<?= $notif['is_read'] == 0 ? 'unread' : '' ?>">
                            <?= htmlspecialchars($notif['message']) ?><br>
                            <small><?= htmlspecialchars($notif['CreatedAt']) ?></small>
                        </li>
                    <?php else: ?>
                        <li><em>⚠️ Invalid notification data</em></li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </div>

        
    </header>

    <!-- second section -->
    <section class="second">
        <div class="title">
            <h2>SERVICES AND PRODUCTS</h2>
            <div class="line"></div>
        </div>
        <div class="row">
            <div class="col">
                <img src="../images/1.jpg" alt="">
                <h4>DELIVERY SERVICES</h4>
                <p>We offer delivery services within a 1-kilometer radius of our store locations, ensuring prompt and convenient access to our products.</p>
            </div>
            <div class="col">
                <img src="../images/2.png" alt="">
                <h4>ROUND GALLON</h4>
                <p>Our round refill gallons are designed for durability and ease of use, providing a reliable solution for your water storage needs.</p>
            </div>
            <div class="col">
                <img src="../images/3.png" alt="">
                <h4>SLIM GALLON</h4>
                <p>We also offer 20-liter rectangular water containers equipped with faucets, combining space-saving design with convenient dispensing.</p>
            </div>
        </div>
    </section>

    <!-- third section -->
    <section class="third">
        <div class="row">
            <div class="col third-content">
                <h1>Enhancing Efficiency with Online Management System</h1>    
                <div class="line"></div>
                <p>By using an online management system, Kylie’s Water Refilling Station can make everyday tasks faster and more organized. It helps track orders, monitor inventory, schedule deliveries, and manage customer records all in one place. This means less paperwork, fewer mistakes, and more time to focus on serving customers.</p>
            <p>With everything updated in real time, Kylie and her team can work smarter—not harder. It saves time, reduces manual errors, and improves customer satisfaction by making sure nothing is missed. In short, it’s a smart way to run the business smoothly and grow confidently.</p>
        </div>
        <div class="col third-image">
            <div class="image">
                <img src="../images/carry.jpg" alt="">
            </div>
            </div>
        </div>
        
    </section>

    <!-- footer page -->
    <footer class="endpage">
        <div class="footer_info">
            <div class="footer-end about">
                <h2>About</h2>
                <p>Water refilling station, is dedicated on providing the neighborhood an access for an affordable, clean, and safe drinking water to our community. We make sure every drop meets the highest standard of quality through precise filtration and managing, as we were founded with a focus on health and service. Our mission is to serve families with convenience, trust and care —one refill at a time.</p>
            </div>
            <div class="footer-end link">
                <h2>Quick Link</h2>
                <ul>
                    <li><a href="../CUSTOMER/cushome.php">Home</a></li>
                    <li><a href="../CUSTOMER/custprofile.php">Profile</a></li>
                    <li><a href="../CUSTOMER/order.php">Order</a></li>
                    <li><a href="../CUSTOMER/aboutus.html">About</a></li>
                    <li><a href="../CUSTOMER/contacts.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-end contact">
                <h2>Contact</h2>
                <ul>
                    <li>
                    <span><i class='bx bxs-map'></i></span>
                    <p>
                       Sauyo Street Quezon City, Philippines
                    </p>
                    </li>
                    <li>
                        <span><i class='bx bxs-envelope'></i></span> 
                        <a href="#">kylie@waterrefillingstation.com</a>
                    </li>
                    <li>
                        <span><i class='bx bxs-phone'></i></span>
                        <p>+63900000000</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="copy-right">
           <p>(c) COPYRIGHT 2025 KYLIE'S WATER REFILLING STATION ALL RIGHTS RESERVED.</p>
        </div>
    </footer>
    
    <script>
        const menuBtn = document.querySelector('.menu-btn')
        const navlinks = document.querySelector('.nav-links')

        menuBtn.addEventListener('click',()=>{
            navlinks.classList.toggle('mobile-menu')
        })

        function openNotifModal() {
            const modal = document.getElementById("notifModal");
            modal.style.display = "block";

            // Mark as read
            fetch('mark1_notif_seen.php')
                .then(() => {
                    const dot = document.querySelector('.notif-dot');
                    dot.classList.remove('red-dot');
                    dot.classList.add('gray-dot');
                });
        }
  function dismissNotif() {
    document.getElementById("notifModal").style.display = "none";
  }

            
    </script>
    <audio id="notifSound" src="/notifs.mp3" preload="auto"></audio>
    <script src="notif_customer_checker.js"></script>

</body>
</html>