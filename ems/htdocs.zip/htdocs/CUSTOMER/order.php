<?php
    session_start();
    $con = mysqli_connect("localhost", "root", "", "kylies");
    if (!$con) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Load from JSON file
    $productsJson = file_get_contents('../ADMIN/products.json');
    $products = json_decode($productsJson, true);

    if (!file_exists('../ADMIN/products.json')) {
    file_put_contents('../ADMIN/products.json', json_encode([]));
    }
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>    
    <link rel="stylesheet" href="order.css">
    <title>Product List</title>
</head>
<body class="">
    <div class="container">
        <nav class="navbar">
            <a href="cushome.php">Home</a>
            <a href="../CUSTOMER/custprofile.php">Profile</a>
            <a href="../CUSTOMER/aboutus.html">About Us</a>
            <a href="../CUSTOMER/contacts.php">Contact Us</a>
            <a href="../php/logout.php">Logout</a>
        </nav>

        <header>
            <div class="title">PRODUCT LIST</div>
            <div class="icon-cart">
                <i class='bx bxs-cart'></i>
                <span>0</span>
            </div>
        </header>

            <div class="listProduct">
            <?php foreach($products as $product): ?>
                <div class="item" data-id="<?php echo $product['id']; ?>">
                    <?php 
                        $imageFile = !empty($product['Image']) ? $product['Image'] : 'default.png';
                    ?>
                    <img src="../images/<?php echo $imageFile; ?>" alt="<?php echo htmlspecialchars($product['ProductName']); ?>">
                    <h2><?php echo htmlspecialchars($product['ProductName']); ?></h2>
                    <div class="price">₱<?php echo number_format($product['Price'], 2); ?></div>
                    <div class="stock">Stocks: <?php echo htmlspecialchars($product['Stocks']); ?></div>
                    <button class="addCart" <?= $product['Stocks'] <= 0 ? 'disabled' : '' ?>>Add To Cart</button>
                </div>
            <?php endforeach ?>
            </div>
        </div>


    <div class="cartTab">
        <h1>Order Cart</h1>
        <div class="listCart">
            <div class="item">
                <i class='bx bx-cart'></i>
            </div>
        </div>
        <div class="total-display" style="text-align:center; font-size: 18px; margin-top: 10px; font-weight: bold;">
            Total :<span id="totalAmountDisplay"></span>
        </div>

        <form class="btn" action="payment.php" method="post" id="checkoutForm">
            <button type="button" class="close">CLOSE</button>
            <input type="hidden" name="cart_data" id="cart_data">
            <input type="hidden" name="Amount" id="Amount">
            <button type="submit" class="checkout-link">CHECK OUT</button>
        </form>
   
    </div>

    <footer class="endpage">
        <div class="footer_info">
            <div class="footer-end about">
                <h2>About</h2>
                <p>Water refilling station, is dedicated on providing the neighborhood an access for an affordable, clean, and safe drinking water to our community. We make sure every drop meets the highest standard of quality through precise filtration and managing, as we were founded with a focus on health and service. Our mission is to serve families with convenience, trust and care —one refill at a time.</p>
            </div>
            <div class="footer-end link">
                <h2>Quick Link</h2>
                <ul>
                    <li><a href="../CUSTOMER/cushome.php">Home</a></li>
                    <li><a href="../CUSTOMER/custprofile.php">Profile</a></li>
                    <li><a href="../CUSTOMER/order.php">Order</a></li>
                    <li><a href="../CUSTOMER/aboutus.html">About</a></li>
                    <li><a href="../CUSTOMER/contacts.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-end contact">
                <h2>Contact</h2>
                <ul>
                    <li>
                        <span><i class='bx bxs-map'></i></span>
                        <p>Sauyo Street Quezon City, Philippines</p>
                    </li>
                    <li>
                        <span><i class='bx bxs-envelope'></i></span> 
                        <a href="#">kylie@waterrefillingstation.com</a>
                    </li>
                    <li>
                        <span><i class='bx bxs-phone'></i></span>
                        <p>+63900000000</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="copy-right">
            <p>(c) COPYRIGHT 2025 KYLIE'S WATER REFILLING STATION ALL RIGHTS RESERVED.</p>
        </div>
    </footer>

    <script src="product.js"></script>
</body>
</html>
