<?php
session_start();
?>


 <!DOCTYPE html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="contacts.css">
        <title>Contact Us Form</title>
    </head>
    <body>
        
        <div class="container">
            <img src="../images/bg lg.jpg" alt=""> 
        </div>

        <nav class="navbar">
            <ul class="nav-links">
                <li><a href="../CUSTOMER/cushome.php">HOME</a></li>
                <li><a href="../CUSTOMER/order.php">ORDER</a></li>
                <li><a href="../CUSTOMER/custprofile.php">PROFILE</a></li>
                <li><a href="../CUSTOMER/aboutus.html">ABOUT</a></li>   
                <li><a href="logout.php">LOGOUT</a></li>
            </ul>
        </nav>

        <div class="contacts">
    
    <form action="#">
        <h1>Contact Us Form</h1>
        
        <div class="index-box">
            <div class="input-field field">
                <input type="text" placeholder="Full Name" id="name" class="item" autocomplete="off">
                <div class="error-txt">Full Name can't be blank</div>
            </div>
            <div class="input-field field">
                <input type="text" placeholder="Email Address" id="email" class="item" autocomplete="off">
                <div class="error-txt email">Email Address can't be blank</div>
            </div>

            <div class="input-field field">
                <input type="text" placeholder="Mobile Number" id="phone" class="item" autocomplete="off">
                <div class="error-txt">Mobile Number can't be blank</div>
            </div>
            <div class="input-field field">
                <input type="text" placeholder="Subject" id="subject" class="item" autocomplete="off">
                <div class="error-txt">Subject can't be blank</div>
            </div>
        </div>

        <div class="textarea-field field">
            <textarea name="" id="message" cols="30" rows="10" placeholder="How can we help you.." class="item" autocomplete="off"></textarea>
            <div class="error-txt">Message can't be blank</div>
        </div>

        <button type="submit">Send Message</button>
    </form>
</div>

    <footer class="endpage">
        <div class="footer_info">
            <div class="footer-end about">
                <h2>About</h2>
                <p>Water refilling station, is dedicated on providing the neighborhood an access for an affordable, clean, and safe drinking water to our community. We make sure every drop meets the highest standard of quality through precise filtration and managing, as we were founded with a focus on health and service. Our mission is to serve families with convenience, trust and care —one refill at a time.</p>
            </div>
            <div class="footer-end link">
                <h2>Quick Link</h2>
                <ul>
                    <li><a href="../CUSTOMER/cushome.php">Home</a></li>
                    <li><a href="../CUSTOMER/custprofile.php">Profile</a></li>
                    <li><a href="../CUSTOMER/order.php">Order</a></li>
                    <li><a href="../CUSTOMER/aboutus.html">About</a></li>
                    <li><a href="../CUSTOMER/contacts.php">Contact</a></li>
                </ul>
            </div>
            <div class="footer-end contact">
                <h2>Contact</h2>
                <ul>
                    <li>
                        <span><i class='bx bxs-map'></i></span>
                        <p>Sauyo Street Quezon City, Philippines</p>
                    </li>
                    <li>
                        <span><i class='bx bxs-envelope'></i></span> 
                        <a href="#">kylie@waterrefillingstation.com</a>
                    </li>
                    <li>
                        <span><i class='bx bxs-phone'></i></span>
                        <p>+63900000000</p>
                    </li>
                </ul>
            </div>
        </div>
        <div class="copy-right">
            <p>(c) COPYRIGHT 2025 KYLIE'S WATER REFILLING STATION ALL RIGHTS RESERVED.</p>
        </div>
    </footer>


<script src="contact.js"></script>
<script src="https://smtpjs.com/v3/smtp.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    </body>
</html> 








