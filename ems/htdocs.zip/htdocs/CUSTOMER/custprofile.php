<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

$con = mysqli_connect("localhost", "root", "", "kylies");
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$originalUsername = $_SESSION["Username"];

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newUsername = mysqli_real_escape_string($con, $_POST["Username"]);
    $email = mysqli_real_escape_string($con, $_POST["Email"]);
    $address = mysqli_real_escape_string($con, $_POST["Address"]);
    $mobile = mysqli_real_escape_string($con, $_POST["MobileNumber"]);
    $password = mysqli_real_escape_string($con, $_POST["Password"]);

    if (!preg_match("/^09\d{9}$/", $mobile)) {
        echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
        echo "<script>
            document.addEventListener('DOMContentLoaded', function() {
                Swal.fire({
                    icon: 'warning',
                    title: 'Invalid Mobile Number!',
                    text: 'Mobile number must start with 09 and be 11 digits long.'
                });
            });
        </script>";
    } else {
        $hashedpassword = password_hash($password, PASSWORD_DEFAULT);
        $updateQuery = "UPDATE kyliescustomers 
                        SET Username='$newUsername', Email='$email', Address='$address', MobileNumber='$mobile', Password='$hashedpassword' 
                        WHERE Username='$originalUsername'";

        if (mysqli_query($con, $updateQuery)) {
            $_SESSION["Username"] = $newUsername;
            header("Location: custprofile.php?updated=true");
            exit;
        } else {
            echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
            echo "<script>
                document.addEventListener('DOMContentLoaded', function() {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error updating profile!',
                        text: '" . mysqli_error($con) . "'
                    });
                });
            </script>";
        }
    }
}

// Fetch user data
$result = mysqli_query($con, "SELECT * FROM kyliescustomers WHERE Username='" . $_SESSION["Username"] . "'");
$data = mysqli_fetch_assoc($result);

// Show success alert if redirected after update
if (isset($_GET['updated']) && $_GET['updated'] === 'true') {
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {
            Swal.fire({
                icon: 'success',
                title: 'Profile updated successfully!',
                showConfirmButton: false,
                timer: 2000
            });
        });
    </script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profile Settings</title>
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="custprofile.css">
    
</head>
<body>

<nav class="navbar">
  <img src="../images/logo.png">
    <ul class="nav-links">
        <li><a href="cushome.php">HOME</a></li>
        <li><a href="order.php">ORDER</a></li>
        <li><a href="aboutus.html">ABOUT</a></li>
        <li><a href="contacts.php">CONTACT</a></li>
        <li><a href="logout.php">LOGOUT</a></li>
    </ul>
</nav>

<div class="profile-container">
    <h2>PROFILE SETTING</h2>

    <?php if ($data): ?>
    <form action="" method="post">
        <label for="Username">USERNAME :</label>
        <input type="text" name="Username" value="<?php echo htmlspecialchars($data['Username']); ?>">

        <label for="Email">E-MAIL :</label>
        <input type="email" name="Email" value="<?php echo htmlspecialchars($data['Email']); ?>">

        <label for="Address">ADDRESS :</label>
        <input type="text" name="Address" value="<?php echo htmlspecialchars($data['Address']); ?>">

        <label for="MobileNumber">MOBILE NO. :</label>
        <input type="text" name="MobileNumber" value="<?php echo htmlspecialchars($data['MobileNumber']); ?>" placeholder="e.g. 09123456789">

        <label for="Password">PASSWORD :</label>
        <div class="password-wrapper">
            <input type="password" name="Password" id="passwordField" value="<?php echo htmlspecialchars($data['Password']); ?>">
            <span class="toggle-password" onclick="togglePassword()">Show Password</span>
        </div>

        <button type="submit" class="save-btn">SAVE CHANGES</button>
    </form>
    <?php else: ?>
        <p>No user data found.</p>
    <?php endif; ?>
</div>

<!-- Order History Section -->
<div class="order-history-container">
    <h2>HISTORY OF ORDERS</h2>
    <div class="order-table-wrapper">
        <table class="order-history-table">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Address</th>
                    <th>Payment Method</th>
                    <th>Mobile Number</th>
                    <th>Amount</th>
                    <th>Delivery Date</th>
                    <th>Order Date</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $ordersQuery = "SELECT * FROM orders WHERE Username = '$originalUsername' ORDER BY ID DESC";
                $ordersResult = mysqli_query($con, $ordersQuery);

                if (mysqli_num_rows($ordersResult) > 0) {
                    while ($row = mysqli_fetch_assoc($ordersResult)) {
                        echo "<tr>";
                        echo "<td>{$row['Username']}</td>";
                        echo "<td>{$row['FullName']}</td>";
                        echo "<td>{$row['Address']}</td>";
                        echo "<td>{$row['PaymentMethod']}</td>";
                        echo "<td>{$row['MobileNumber']}</td>";
                        echo "<td>{$row['Amount']}</td>";
                        echo "<td>{$row['DeliveryDate']}</td>";
                        echo "<td>{$row['OrderDate']}</td>";
                        echo "<td>{$row['status']}</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No order history found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>


<footer class="endpage">
    <div class="footer_info">
        <div class="footer-end about">
            <h2>About</h2>
            <p>Water refilling station, is dedicated on providing the neighborhood an access for an affordable, clean, and safe drinking water to our community. We make sure every drop meets the highest standard of quality through precise filtration and managing, as we were founded with a focus on health and service. Our mission is to serve families with convenience, trust and care — one refill at a time.</p>
        </div>
        <div class="footer-end link">
            <h2>Quick Link</h2>
            <ul>
                <li><a href="../CUSTOMER/cushome.php">Home</a></li>
                <li><a href="../CUSTOMER/custprofile.php">Profile</a></li>
                <li><a href="../CUSTOMER/order.php">Order</a></li>
                <li><a href="../CUSTOMER/aboutus.html">About</a></li>
                <li><a href="../CUSTOMER/contacts.php">Contact</a></li>
            </ul>
        </div>
        <div class="footer-end contact">
            <h2>Contact</h2>
            <ul>
                <li>
                    <span><i class='bx bxs-map'></i></span>
                    <p>Sauyo Street Quezon City, Philippines</p>
                </li>
                <li>
                    <span><i class='bx bxs-envelope'></i></span>
                    <a href="#">kylie@waterrefillingstation.com</a>
                </li>
                <li>
                    <span><i class='bx bxs-phone'></i></span>
                    <p>+63900000000</p>
                </li>
            </ul>
        </div>
    </div>
    <div class="copy-right">
        <p>(c) COPYRIGHT 2025 KYLIE'S WATER REFILLING STATION ALL RIGHTS RESERVED.</p>
    </div>
</footer>


<script>
    function togglePassword() {
        const passwordInput = document.getElementById("passwordField");
        const toggleText = document.querySelector(".toggle-password");
        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            toggleText.textContent = "Hide Password";
        } else {
            passwordInput.type = "password";
            toggleText.textContent = "Show Password";
        }
    }
</script>

</body>
</html>
