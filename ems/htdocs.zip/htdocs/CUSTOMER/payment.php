<?php 
session_start();

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("location: login.php");
    exit;
}

$con = new mysqli("localhost", "root", "", "kylies");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$orderSuccess = false;
$Username = $_SESSION["Username"];
$profileResult = mysqli_query($con, "SELECT Address, MobileNumber FROM kyliescustomers WHERE Username='$Username'");
$profileData = mysqli_fetch_assoc($profileResult);

if (isset($_POST['Submit_Order'])) {
    $FullName = $_POST['FullName'] ?? '';
    $Address = $_POST['Address'] ?? '';
    $MobileNumber = $_POST['MobileNumber'] ?? '';
    $PaymentMethod = $_POST['PaymentMethod'] ?? '';
    $Amount = $_POST['Amount'] ?? '';
    $DeliveryDate = $_POST['DeliveryDate'] ?? '';
    
    $cartData = json_decode($_POST['cart_data'] ?? '[]', true);

    $products = $_POST['cart_data'];

    $stmt = $con->prepare("INSERT INTO orders (FullName, Address, MobileNumber, PaymentMethod, Products, Amount, DeliveryDate, Username) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssss", $FullName, $Address, $MobileNumber, $PaymentMethod, $products, $Amount, $DeliveryDate, $Username);

    if ($stmt->execute()) {
        $orderSuccess = true;

        $orderId = $con->insert_id;
        $status = "Pending";
        $notifMessage = "Your order ID $orderId has been placed successfully and is now $status.";

        mysqli_query($con, "INSERT INTO notifcustomer (Username, Message, Status, CreatedAt, is_read)
                            VALUES ('$Username', '$notifMessage', '$status', NOW(), 0)");

        // Insert dashboard notification for admin
        $adminMessage = "Order ID: $orderId | Customer: $FullName | Amount: ₱" . number_format($Amount, 2);
        mysqli_query($con, "INSERT INTO notifications (type, message, created_at) VALUES ('order', '$adminMessage', NOW())");


        foreach ($cartData as $item) {
            $productId = intval($item['product_id']);
            $quantity = intval($item['quantity']);
            mysqli_query($con, "UPDATE products SET Stocks = Stocks - $quantity WHERE id = $productId AND Stocks >= $quantity");
        }

        $productQuery = mysqli_query($con, "SELECT * FROM products");
        $products = [];
        while ($row = mysqli_fetch_assoc($productQuery)) {
            $products[] = $row;
        }
        file_put_contents('../ADMIN/products.json', json_encode($products, JSON_PRETTY_PRINT));
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Payment</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <link rel="stylesheet" href="payment.css">
</head>
<body>

<a href="order.php" class="prev-page"><i class='bx bx-left-arrow-alt'></i></a>

<div class="container">
    <form action="payment.php" method="POST" id="checkoutForm">
        <div class="row">
            <div class="col">
                <h3 class="title">Billing Address</h3>
                <div class="inputBox">
                    <span>Full Name :</span>
                    <input type="text" name="FullName" required placeholder="Full Name">
                </div>
                <div class="inputBox">
                    <span>Address : </span>
                    <input type="text" name="Address" id="address" required
                           value="<?= htmlspecialchars($profileData['Address'] ?? '') ?>">
                </div>
                <div class="inputBox">
                    <span>Mobile Number :</span>
                    <input type="text" name="MobileNumber" required
                           value="<?= htmlspecialchars($profileData['MobileNumber'] ?? '') ?>">
                </div>
                <div class="inputBox">
                    <span>Select Your DateTime Delivery :</span>
                    <input type="datetime-local" name="DeliveryDate" required>
                </div>
            </div>

            <div class="col">
                <h3 class="title">Payment</h3>
                <div class="inputBox1">
                    <b>Select a Payment Method :</b>
                    <input type="radio" name="PaymentMethod" id="gcash" value="GCASH" required>
                    <input type="radio" name="PaymentMethod" id="COD" value="COD" required>

                    <div class="category">
                        <label for="gcash" class="gcashMethod">
                            <div class="imgName">
                                <div class="imgContainer">
                                    <img src="../images/gcash.png" alt="GCASH">
                                </div>
                                <span class="name">GCASH</span>
                            </div>
                        </label>

                        <label for="COD" class="codMethod">
                            <div class="imgName">
                                <div class="imgContainer">
                                    <img src="../images/cod.png" alt="COD">
                                </div>
                                <span class="name">Cash On Delivery</span>
                            </div>
                        </label>
                    </div>
                </div>
                <div class="inputBox">
                    <span>Amount :</span>
                    <input type="text" id="AmountDisplay" readonly>
                </div>
                <div class="inputBox">
                    <span>Product - Quantity</span>
                    <input type="text" id="ProQu" readonly>
                </div>
            </div>
        </div>
        <input type="hidden" name="cart_data" id="cart_data">
        <input type="hidden" name="Amount" id="Amount">
        <button type="submit" name="Submit_Order" class="submit-btn">Submit</button>
        <p class="note"><strong>NOTE:</strong> Pick-up time for gallon when you order for REFILL ONLY. 10AM AND 3PM</p>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>

<?php if ($orderSuccess): ?>
<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>
<script>
    const paymentMethod = '<?= $PaymentMethod ?>';
    localStorage.removeItem('cart');
    document.addEventListener('DOMContentLoaded', function () {
        Swal.fire({ icon: 'success', title: 'Order Successful!', showConfirmButton: false, timer: 2000 });
        setTimeout(function () {
            window.location.href = (paymentMethod === 'GCASH') ? 'gcash.html' : '../CUSTOMER/order.php';
        }, 2000);
    });
</script>
<?php endif; ?>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const hiddenCartInput = document.getElementById('cart_data');
    const amountInput = document.getElementById('Amount');
    const amountDisplay = document.getElementById('AmountDisplay');

    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    hiddenCartInput.value = JSON.stringify(cart);

    // Fetch products.json to get prices
    fetch('../ADMIN/products.json')
        .then(res => res.json())
        .then(products => {
            let total = 0;

            cart.forEach(item => {
                const product = products.find(p => p.id == item.product_id);
                if (product) {
                    total += product.Price * item.quantity;
                }
            });

            const summary = cart.map(item => {
                const product = products.find(p => p.id == item.product_id);
                if (product) {
                    return `${product.Acronym} x${item.quantity}`;
                }
                return '';
            }).filter(Boolean).join(', ');

            document.getElementById('ProQu').value = summary;
            amountInput.value = total.toFixed(2);
            amountDisplay.value = total.toFixed(2);
        });
}); 
</script>


</body>
</html>
