// Unlock autoplay with first user click
document.addEventListener('click', () => {
    const sound = document.getElementById("notifSound");
    if (sound) {
        sound.play().catch(() => {});
    }
}, { once: true });

let unreadCount = parseInt(document.body.getAttribute('data-initial-unread')) || 0;

function checkNewNotifications() {
    fetch('get_unread_notif_count.php')
        .then(response => response.json())
        .then(data => {
            const newCount = data.count;
            if (newCount > unreadCount) {
                // Play sound
                const sound = document.getElementById("notifSound");
                if (sound) sound.play().catch(() => {});

                // Change red dot
                const dot = document.querySelector('.notif-dot');
                if (dot) {
                    dot.classList.remove('gray-dot');
                    dot.classList.add('red-dot');
                }

                // Show toast popup
                showNotificationToast("🔔 You have a new notification");

                // Update count
                unreadCount = newCount;
            }
        });
}

// Optional: play sound when notification bell is clicked
document.querySelector('.notif_icon')?.addEventListener('click', () => {
    const sound = document.getElementById("notifSound");
    if (sound) sound.play().catch(() => {});
});

setInterval(checkNewNotifications, 60000);
document.addEventListener('DOMContentLoaded', checkNewNotifications);


function showNotificationToast(message) {
    let toast = document.createElement('div');
    toast.className = 'notif-toast';
    toast.innerText = message;

    document.body.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('show');
    }, 10);

    // Auto-remove after 3 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => document.body.removeChild(toast), 300);
    }, 30000);
}
