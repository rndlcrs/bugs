<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "kylies");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

$today = date('Y-m-d');
include 'notif_check.php';


// Get static dashboard values
$query = "SELECT total_income, total_customers FROM dashboard LIMIT 1";
$result = mysqli_query($con, $query);
$data = mysqli_fetch_assoc($result);

// Get total income (from orders)
// Get income range (daily, weekly, monthly)
$range = $_GET['range'] ?? 'daily';
$income_query = "";  // always define
$income_label = "Income";

switch ($range) {
    case 'weekly':
        $income_query = "SELECT SUM(Amount) AS total_income FROM orders WHERE YEARWEEK(DeliveryDate, 1) = YEARWEEK(CURDATE(), 1)";
        $income_label = "Weekly Income";
        break;
    case 'by_month':
        $selectedMonth = $_GET['month'] ?? '';
        if ($selectedMonth) {
            $income_query = "SELECT SUM(Amount) AS total_income FROM orders WHERE DATE_FORMAT(DeliveryDate, '%Y-%m') = '$selectedMonth'";
            $income_label = "Income for " . date('F Y', strtotime($selectedMonth));
        }
        break;  
    case 'all':
        $income_query = "SELECT SUM(Amount) AS total_income FROM orders";
        $income_label = "Total Income (All Time)";
        break;
    case 'custom':
    $start = $_GET['start_date'] ?? '';
    $end = $_GET['end_date'] ?? '';
    if ($start && $end) {
        $income_query = "SELECT SUM(Amount) AS total_income FROM orders WHERE DeliveryDate BETWEEN '$start' AND '$end'";
        $income_label = "Income from $start to $end";
    }
    break;
    case 'daily':
    default:
        $income_query = "SELECT SUM(Amount) AS total_income FROM orders WHERE DATE(OrderDate) = CURDATE()";
        $income_label = "Daily Income";
        break;
}

if (!empty($income_query)) {
    $income_result = mysqli_query($con, $income_query);
    $income_data = mysqli_fetch_assoc($income_result);
    $total_income = $income_data['total_income'] ?? 0;
} else {
    $total_income = 0;
}


// Get total customers
$customers_query = "SELECT COUNT(*) AS total_customers FROM kyliescustomers";
$customers_result = mysqli_query($con, $customers_query);
$customers_data = mysqli_fetch_assoc($customers_result);
$total_customers = $customers_data['total_customers'] ?? 0;

// Get monthly orders
$order_range = $_GET['orders'] ?? 'daily';

switch ($order_range) {
    case 'weekly':
        $orders_query = "SELECT COUNT(*) AS total_orders FROM orders WHERE YEARWEEK(DeliveryDate, 1) = YEARWEEK(CURDATE(), 1)";
        $orders_label = "Weekly Orders";
        break;

    case 'orders_month':
        $ordersMonth = $_GET['orders_month'] ?? '';
        if ($ordersMonth) {
            $orders_query = "SELECT COUNT(*) AS total_orders FROM orders WHERE DATE_FORMAT(DeliveryDate, '%Y-%m') = '$ordersMonth'";
            $orders_label = "Orders for " . date('F Y', strtotime($ordersMonth));
        } else {
            $orders_query = "SELECT 0 AS total_orders";
            $orders_label = "Invalid Month";
        }
        break;

    case 'orders_custom':
        $ordersStart = $_GET['orders_start'] ?? '';
        $ordersEnd = $_GET['orders_end'] ?? '';
        if ($ordersStart && $ordersEnd) {
            $orders_query = "SELECT COUNT(*) AS total_orders FROM orders WHERE DeliveryDate BETWEEN '$ordersStart' AND '$ordersEnd'";
            $orders_label = "Orders from $ordersStart to $ordersEnd";
        } else {
            $orders_query = "SELECT 0 AS total_orders";
            $orders_label = "Invalid Date Range";
        }
        break;

    case 'all':
        $orders_query = "SELECT COUNT(*) AS total_orders FROM orders";
        $orders_label = "All Orders";
        break;

    case 'daily':
    default:
        $orders_query = "SELECT COUNT(*) AS total_orders FROM orders WHERE DATE(OrderDate) = CURDATE()";
        $orders_label = "Daily Orders";
        break;
}

if (!empty($orders_query)) {
    $orders_result = mysqli_query($con, $orders_query);
    $orders_data = mysqli_fetch_assoc($orders_result);
    $total_orders = $orders_data['total_orders'] ?? 0;
} else {
    $total_orders = 0;
}

// Prepare chart data arrays

$customerChartData = [
    'daily' => [],
    'monthly' => [],
    'yearly' => [],
];
$incomeChartData = [
    'daily' => [],
    'monthly' => [],
    'yearly' => [],
];


// CUSTOMERS
// Daily - last 7 days
$res = mysqli_query($con, "SELECT DATE(CreatedDate) AS label, COUNT(*) AS count FROM kyliescustomers WHERE CreatedDate >= CURDATE() - INTERVAL 7 DAY GROUP BY label");
while ($row = mysqli_fetch_assoc($res)) {
    $customerChartData['daily'][] = $row;
}

// Monthly - this year
$monthly_customer_counts = array_fill(1, 12, 0); // Jan to Dec = 0
$res = mysqli_query($con, "SELECT MONTH(CreatedDate) AS month, COUNT(*) AS count FROM kyliescustomers WHERE YEAR(CreatedDate) = YEAR(CURDATE()) GROUP BY month");
while ($row = mysqli_fetch_assoc($res)) {
    $monthly_customer_counts[(int)$row['month']] = (int)$row['count'];
}

foreach (range(1, 12) as $m) {
    $customerChartData['monthly'][] = [
        'label' => date('F', mktime(0, 0, 0, $m, 1)),
        'count' => $monthly_customer_counts[$m]
    ];
}

// Yearly - last 5 years
$startYear = date('Y') - 1; // example: 2024 if this year is 2025
$endYear = $startYear + 4;  // example: 2028

$yearly_customer_counts = array_fill_keys(range($startYear, $endYear), 0);

$res = mysqli_query($con, "SELECT YEAR(CreatedDate) AS year, COUNT(*) AS count FROM kyliescustomers WHERE YEAR(CreatedDate) BETWEEN $startYear AND $endYear GROUP BY year");
while ($row = mysqli_fetch_assoc($res)) {
    $year = (int)$row['year'];
    $yearly_customer_counts[$year] = (int)$row['count'];
}

foreach ($yearly_customer_counts as $year => $count) {
    $customerChartData['yearly'][] = [
        'label' => (string)$year,
        'count' => $count
    ];
}


// INCOME
// Daily - last 7 days
$res = mysqli_query($con, "SELECT DATE(OrderDate) AS label, SUM(Amount) AS count FROM orders WHERE OrderDate >= CURDATE() - INTERVAL 7 DAY GROUP BY label");
while ($row = mysqli_fetch_assoc($res)) {
    $incomeChartData['daily'][] = $row;
}

// Monthly - this year
$monthly_income_amounts = array_fill(1, 12, 0); // Jan to Dec = 0
$res = mysqli_query($con, "SELECT MONTH(OrderDate) AS month, SUM(Amount) AS total FROM orders WHERE YEAR(OrderDate) = YEAR(CURDATE()) GROUP BY month");
while ($row = mysqli_fetch_assoc($res)) {
    $monthly_income_amounts[(int)$row['month']] = (float)$row['total'];
}

foreach (range(1, 12) as $m) {
    $incomeChartData['monthly'][] = [
        'label' => date('F', mktime(0, 0, 0, $m, 1)),
        'count' => $monthly_income_amounts[$m]
    ];
}


// Yearly - last 5 years
$yearly_income_totals = array_fill_keys(range($startYear, $endYear), 0.00);

$res = mysqli_query($con, "SELECT YEAR(OrderDate) AS year, SUM(Amount) AS total FROM orders WHERE YEAR(OrderDate) BETWEEN $startYear AND $endYear GROUP BY year");
while ($row = mysqli_fetch_assoc($res)) {
    $year = (int)$row['year'];
    $yearly_income_totals[$year] = (float)$row['total'];
}

foreach ($yearly_income_totals as $year => $total) {
    $incomeChartData['yearly'][] = [
        'label' => (string)$year,
        'count' => $total
    ];
}



?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard</title>
    <link rel="stylesheet" href="dashboard.css">
</head>
<body>
    <div class="side-menu">
        <div class="brand-name">
            
        </div>
        
        <div class="side-menu-user">
            <img src="../images/logo.png" alt="">
            <div>
                <h3>Kylie's Water Refilling Station</h3>
                <span><u>kylierefilling@gmail.com</u></span>
            </div>
        </div>
        <ul>
            <li><a href="dashboard.php">DASHBOARD</a></li>
            <li><a href="allcust.php">CUSTOMERS</a></li>
            <li><a href="allprods.php">PRODUCTS</a></li>
            <li><a href="allorders.php">ORDERS</a></li>
        </ul>
    </div>

    <div class="wrapper">
        <h1>DASHBOARD</h1>
        <div class="notif_wrapper">
            <a href="#" onclick="openNotifModal(); return false;">
            <img class="notif_icon" src="../images/notif.png" alt="">
            <?php if ($has_unread): 'color: #fc036b;'?>
                <span class="notif-dot red-dot"></span>
            <?php else: ?>
                <span class="notif-dot gray-dot"></span>
            <?php endif; ?>
        </a>
        </div>

        <div class="log"><a href="/adminlogin.php">Logout</a></div>
    </div>

        <div class="dashboard-cards">
            <div class="card">
                <div class="card-icon"><img src="../images/customers.png" alt="Customers"></div>
                <div>
                    <h2><?php echo $total_customers; ?></h2>
                    <p>Customers</p>
                </div>
            </div>
            <div class="card income-card">
                <div class="card-icon"><img src="../images/income.png" alt="Income"></div>
                <div class="income-dropdown">
                    <div class="dropdown">
                        <button onclick="toggleDropdown()" class="dropbtn">TOTAL INCOME ▾</button>
                        <div id="incomeDropdown" class="dropdown-content">
                            <a href="?range=daily">TODAY</a>
                            <a href="?range=weekly">WEEKLY</a>
                            <a href="#" onclick="showMonthFilter(true); return false;">MONTHLY</a>
                            <a href="?range=all">ALL</a>
                            <a href="#" onclick="showCustomFilter(true); return false;">CUSTOM RANGE</a>
                        </div>
                    </div>
                    <h2>₱<?= number_format($total_income, 2); ?></h2>
                    <p><?= $income_label ?></p>
                </div>
            </div>

            <div id="filterPanel" class="filter-panel">
            <form id="monthPickerForm" method="get">
                <label>Select Month:</label>
                <input type="month" name="month" required>
                <input type="hidden" name="range" value="by_month">
                <button type="submit">Filter</button>
            </form>

            <form id="customRangeForm" method="get">
                <label>From:</label>
                <input type="date" name="start_date" required>
                <label>To:</label>
                <input type="date" name="end_date" required>
                <input type="hidden" name="range" value="custom">
                <button type="submit">Filter</button>
            </form>
            </div>


            <div class="card orders-card">
                <div class="card-icon"><img src="../images/order.png" alt="Orders"></div>
                <div class="orders-dropdown">
                    <div class="dropdown">
                        <button onclick="toggleOrderDropdown()" class="dropbtn">ORDERS ▾</button>
                        <div id="ordersDropdown" class="dropdown-content">
                        <a href="?range=<?= $range ?>&orders=daily">TODAY</a>
                        <a href="?range=<?= $range ?>&orders=weekly">WEEKLY</a>
                        <a href="#" onclick="showOrdersMonthFilter(); return false;">MONTHLY</a>
                        <a href="?range=<?= $range ?>&orders=all">ALL</a>
                        <a href="#" onclick="showOrdersCustomFilter(); return false;">CUSTOM RANGE</a>
                        </div>
                    </div>
                    <h2><?= $total_orders; ?></h2>
                    <p><?= $orders_label; ?></p>
                </div>
            </div>

                        <!-- Orders Filter Panel -->
            <div id="ordersFilterPanel" class="filter-panel">
            <!-- Monthly Picker -->
            <form id="ordersMonthForm" method="get">
                <label>Select Month:</label>
                <input type="month" name="orders_month" required>
                <input type="hidden" name="orders" value="orders_month">                
                <input type="hidden" name="orders" value="orders_month">
                <button type="submit">Filter</button>
            </form>

            <!-- Custom Date Range Picker -->
            <form id="ordersCustomForm" method="get">
                <label>From:</label>
                <input type="date" name="orders_start" required>
                <label>To:</label>
                <input type="date" name="orders_end" required>
                <input type="hidden" name="orders" value="orders_custom">
                <button type="submit">Filter</button>
            </form>
            </div>

        </div>

        <div class="chart-container">
        <div class="chart-box">
            <div class="chart-header">
            <label>Customer:</label>
            <select id="customerRange" onchange="updateChart('customer')">
                <option value="daily" selected>Daily</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
            </select>
            </div>
            <canvas id="customerChart"></canvas>
        </div>

        <div class="chart-box">
            <div class="chart-header">
            <label>Income:</label>
            <select id="incomeRange" onchange="updateChart('income')">
                <option value="daily" selected>Daily</option>
                <option value="monthly">Monthly</option>
                <option value="yearly">Yearly</option>
            </select>
            </div>
            <canvas id="incomeChart"></canvas>
        </div>
        </div>

        <div id="popupNotif" class="popup-notif" style="display: none;">
        <div class="popup-content">
            <span class="close-btn" onclick="dismissNotif()">&times;</span>
            <h4>🔔 Notification</h4>
            <ul>
            <?php foreach ($notifications as $notif): ?>
                <li class="<?= $notif['is_read'] == 0 ? 'unread' : '' ?>">
                    <?= htmlspecialchars($notif['message']) ?>
                    <small style="color:gray">(<?= date("M d H:i", strtotime($notif['created_at'])) ?>)</small>
                </li>

            <?php endforeach; ?>
            </ul>
        </div>
        </div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<audio id="notifSound" src="/notif.mp3" preload="auto"></audio>
<script src="notif_checker.js"></script>

<script>
const customerData = <?= json_encode($customerChartData) ?>;
const incomeData = <?= json_encode($incomeChartData) ?>;

let customerChart, incomeChart;

function initCharts() {
  updateChart('customer');
  updateChart('income');
}

function updateChart(type) {
  const range = document.getElementById(type + 'Range').value;
  const dataSet = (type === 'customer') ? customerData[range] : incomeData[range];

  const labels = dataSet.map(item => item.label).reverse();
  const values = dataSet.map(item => item.count).reverse();

  const ctx = document.getElementById(type + 'Chart').getContext('2d');
  const config = {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: type === 'customer' ? 'Customers' : 'Income (₱)',
        data: values,
        fill: false,
        borderColor: type === 'customer' ? 'green' : 'blue',
        tension: 0.3
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { beginAtZero: true }
      }
    }
  };

  if (type === 'customer') {
    if (customerChart) customerChart.destroy();
    customerChart = new Chart(ctx, config);
  } else {
    if (incomeChart) incomeChart.destroy();
    incomeChart = new Chart(ctx, config);
  }
}

document.addEventListener('DOMContentLoaded', initCharts);
</script>



<script>
  function openNotifModal() {
    document.getElementById("popupNotif").style.display = "block";

    // Mark all as read in the backend
    fetch('mark_notif_seen.php')
      .then(response => response.text())
      .then(() => {
        // Change red dot to gray
        const dot = document.querySelector('.notif-dot');
        if (dot) {
          dot.classList.remove('red-dot');
          dot.classList.add('gray-dot');
        }
      });
    }


  function dismissNotif() {
    document.getElementById("popupNotif").style.display = "none";
  }

  function toggleDropdown() {
    document.getElementById("incomeDropdown").classList.toggle("show");
  }

  function toggleOrderDropdown() {
    document.getElementById("ordersDropdown").classList.toggle("show");
  }

  function showMonthFilter() {
  document.getElementById('filterPanel').style.display = 'block';
  document.getElementById('monthPickerForm').classList.add('active');
  document.getElementById('customRangeForm').classList.remove('active');

   if (preserveDropdown) {
    document.getElementById("incomeDropdown").classList.add("show");
  }
}

  function showCustomFilter() {
  document.getElementById('filterPanel').style.display = 'block';
  document.getElementById('monthPickerForm').classList.remove('active');
  document.getElementById('customRangeForm').classList.add('active');

  if (preserveDropdown) {
    document.getElementById("incomeDropdown").classList.add("show");
  }
}

  function showOrdersMonthFilter() {
    document.getElementById('ordersFilterPanel').style.display = 'block';
    document.getElementById('ordersMonthForm').style.display = 'block';
    document.getElementById('ordersCustomForm').style.display = 'none';

      document.getElementById("ordersDropdown").classList.add("show");
  }

  function showOrdersCustomFilter() {
    document.getElementById('ordersFilterPanel').style.display = 'block';
    document.getElementById('ordersMonthForm').style.display = 'none';
    document.getElementById('ordersCustomForm').style.display = 'block';

    document.getElementById("ordersDropdown").classList.add("show");
  }

window.addEventListener('click', function(e) {
  const incomeDropdown = document.getElementById('incomeDropdown');
  const incomePanel = document.getElementById('filterPanel');
  const ordersDropdown = document.getElementById('ordersDropdown');
  const ordersPanel = document.getElementById('ordersFilterPanel');

  const isIncomeDropdown = incomeDropdown.contains(e.target) || e.target.closest('.income-dropdown');
  const isIncomePanel = incomePanel.contains(e.target);
  const isOrdersDropdown = ordersDropdown.contains(e.target) || e.target.closest('.orders-dropdown');
  const isOrdersPanel = ordersPanel.contains(e.target);

  // Hide Income filter if clicked outside
  if (!isIncomeDropdown && !isIncomePanel) {
    incomeDropdown.classList.remove("show");
    incomePanel.style.display = 'none';
  }

  // Hide Orders filter if clicked outside
  if (!isOrdersDropdown && !isOrdersPanel) {
    ordersDropdown.classList.remove("show");
    ordersPanel.style.display = 'none';
  }
});</script>
</body>
</html>
