<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "kylies");

if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}

// Handle product deletion
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = intval($_GET['id']);
    mysqli_query($con, "DELETE FROM products WHERE ID = $id");
}

// Handle new product insertion
if (isset($_POST['new_product']) && $_POST['new_product'] == '1') {
    $name = $_POST['product_name'] ?? '';
    $acronym = $_POST['acronym'] ?? '';
    $price = floatval($_POST['price'] ?? 0);
    $stocks = intval($_POST['stocks'] ?? 0);
    

    $imageName = null;
    if (isset($_FILES['product_image']['name']['new']) && $_FILES['product_image']['error']['new'] === UPLOAD_ERR_OK) {
        $imageName = basename($_FILES['product_image']['name']['new']);
        move_uploaded_file($_FILES['product_image']['tmp_name']['new'], "../images/" . $imageName);
    }

    if (!empty($name)) {
        $stmt = mysqli_prepare($con, "INSERT INTO products (ProductName, Price, Stocks, Image, Acronym) VALUES (?, ?, ?, ?, ?)");
        mysqli_stmt_bind_param($stmt, "sdiss", $name, $price, $stocks, $imageName, $acronym);
        mysqli_stmt_execute($stmt);
    }
}
    

    // Update existing product
if (isset($_POST['products']) && is_array($_POST['products'])) {
    foreach ($_POST['products'] as $product) {
        $id = intval($product['update_id'] ?? 0);
        $name = $product['product_name'] ?? '';
        $acronym = $product['acronym'] ?? '';
        $price = floatval($product['price'] ?? 0);
        $stocks = intval($product['stocks'] ?? 0);

        $imageName = null;
        if (isset($_FILES['product_image']['name'][$id]) && $_FILES['product_image']['error'][$id] === UPLOAD_ERR_OK) {
            $imageName = basename($_FILES['product_image']['name'][$id]);
            move_uploaded_file($_FILES['product_image']['tmp_name'][$id], "../images/" . $imageName);
        }

        if (!empty($name) && $id > 0) {
            if (!empty($imageName)) {
                $stmt = mysqli_prepare($con, "UPDATE products SET ProductName=?, Price=?, Stocks=?, Image=? WHERE ID=?");
                mysqli_stmt_bind_param($stmt, "sdisi", $name, $price, $stocks, $imageName, $id);
            } else {
                    $stmt = mysqli_prepare($con, "UPDATE products SET ProductName=?, Price=?, Stocks=?, Acronym=? WHERE ID=?");
                    mysqli_stmt_bind_param($stmt, "sdssi", $name, $price, $stocks, $acronym, $id);
            }
            mysqli_stmt_execute($stmt);
        }
    }
}


$result = mysqli_query($con, "SELECT * FROM products");
$data = $result->fetch_all(MYSQLI_ASSOC);

// Fetch latest product list from database
$productQuery = mysqli_query($con, "SELECT * FROM products");
$products = [];

while ($row = mysqli_fetch_assoc($productQuery)) {
    $products[] = $row;
}

foreach ($products as &$prod) {
    if (!empty($prod['Image'])) {
        $prod['Image'] = '../images/' . $prod['Image'];
    }
}

// Save to JSON file
file_put_contents('../ADMIN/products.json', json_encode($products, JSON_PRETTY_PRINT));
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="allprods.css">
<title>PRODUCT LIST</title>
</head>
<body>
<header>
    <div class="side-menu">
        <div class="brand-name"></div>
        <div class="title">
            <h3>PRODUCT LIST</h3>
        </div>
        <div class="side-menu-user">
            <img src="../images/logo.png" alt="">
            <div>
                <h3>Kylie's Water Refilling Station</h3>
                <span><u>kylierefilling@gmail.com</u></span>
            </div>
        </div>
        <ul>
            <li><a href="dashboard.php">DASHBOARD</a></li>
            <li><a href="allcust.php">CUSTOMERS</a></li>
            <li><a href="allprods.php">PRODUCTS</a></li>
            <li><a href="allorders.php">ORDERS</a></li>
        </ul>
    </div>
</header>
<main>
    <div class="wrapper">
        <h1>PRODUCTS</h1>
        <div class="log"><a href="/adminlogin.php">Logout</a></div>
    </div>
    <article>
       <br>
<form method="POST" enctype="multipart/form-data" id="productForm" onsubmit="return syncAllRowsBeforeSubmit()">
        <button id="addProductBtn" class="addProductBtn">➕ Add Product</button>
        <div class="scroll-table">
        <table id="productTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Acronym</th>
                    <th>Price</th>
                    <th>Stocks</th>
                    <th>Image</th>
                    <th>Save/Remove</th>
                </tr>

            </thead>
            <tbody id="productBody">
                <?php foreach ($data as $i => $row): ?>
                    <tr>
                        <td><?= $i + 1 ?></td>
                        <td contenteditable="true" id="editableName_<?= $row['id'] ?>"><?= htmlspecialchars($row['ProductName']) ?></td>
                        <td contenteditable="true" id="editableAcronym_<?= $row['id'] ?>"><?= htmlspecialchars($row['Acronym']) ?></td>
                        <td contenteditable="true" id="editablePrice_<?= $row['id'] ?>"><?= htmlspecialchars($row['Price']) ?></td>
                        <td>
                        <?php if (strtolower(trim($row['ProductName'])) === 'water refill only'): ?>
                            <span style="color: gray;">N/A</span>
                            <input type="hidden" id="editableStock_<?= $row['id'] ?>" value="0">
                        <?php else: ?>
                            <button type="button" class="stock-btn minus" onclick="adjustStock(<?= $row['id'] ?>, -1)">➖</button>
                            <span contenteditable="true" class="stock-count" id="editableStock_<?= $row['id'] ?>" oninput="syncRowInputs(<?= $row['id'] ?>)"><?= htmlspecialchars($row['Stocks']) ?></span>
                            <button type="button" class="stock-btn plus" onclick="adjustStock(<?= $row['id'] ?>, 1)">➕</button>
                        <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!empty($row['Image'])): ?>
                                <img src="../images/<?= htmlspecialchars($row['Image']) ?>" alt="Product Image" width="50"><br>
                            <?php endif; ?>
                            <input type="file" class="image" name="product_image[<?= $row['id'] ?>]" accept="image/*">
                        </td>
                        <td>
                            <input type="hidden" id="update_id_<?= $row['id'] ?>" name="products[<?= $row['id'] ?>][update_id]" value="<?= $row['id'] ?>">
                            <input type="hidden" id="name_<?= $row['id'] ?>" name="products[<?= $row['id'] ?>][product_name]">
                            <input type="hidden" id="acronym_<?= $row['id'] ?>" name="products[<?= $row['id'] ?>][acronym]">
                            <input type="hidden" id="price_<?= $row['id'] ?>" name="products[<?= $row['id'] ?>][price]">
                            <input type="hidden" id="stocks_<?= $row['id'] ?>" name="products[<?= $row['id'] ?>][stocks]">
                            <button type="submit" class="save-btn" onclick="syncRowInputs(<?= $row['id'] ?>)">Save</button>
                            <button type="button" class="remove-btn" onclick="removeProduct(<?= $row['id'] ?>)">Remove</button>
                        </td>
                    </tr>
                <?php endforeach; ?>          
            </tbody>
        </table>
        </div>
        </form>
    </article>
</main>

<script>
function syncRowInputs(id) {
    const name = document.getElementById(`editableName_${id}`).innerText.trim();
    const price = document.getElementById(`editablePrice_${id}`).innerText.trim();
    const stock = document.getElementById(`editableStock_${id}`).innerText.trim();
    document.getElementById(`name_${id}`).value = name;
    document.getElementById(`price_${id}`).value = price;
    document.getElementById(`stocks_${id}`).value = stock;
}

function adjustStock(id, change) {
    const stockSpan = document.getElementById(`editableStock_${id}`);
    let current = parseInt(stockSpan.innerText.trim()) || 0;
    current = Math.max(current + change, 0);
    stockSpan.innerText = current;
    syncRowInputs(id);
}

function syncAllRowsBeforeSubmit() {
    const editableNames = document.querySelectorAll('[id^="editableName_"]');
    editableNames.forEach(el => {
        const id = el.id.split('_')[1];
        syncRowInputs(id);
    });
    return true;
}


function autoSaveRow(button) {
    const row = button.closest('tr');
    const saveBtn = row.querySelector('.save-btn');
    saveBtn.click();
}

function removeProduct(id) {
    if (confirm("Are you sure you want to delete this product?")) {
        window.location.href = `allprods.php?id=${id}`;
    }
}

document.getElementById('addProductBtn').addEventListener('click', function () {
    const table = document.getElementById('productBody');
    const newId = Date.now();

    // Create a table row
    const row = document.createElement('tr');
    row.innerHTML = `
         <td></td>
    <td contenteditable="true" id="editableName_${newId}">NEW PRODUCT</td>
    <td contenteditable="true" id="editableAcronym_${newId}"></td>
    <td contenteditable="true" id="editablePrice_${newId}">0</td>
    <td>
        <button type="button" class="stock-btn minus" onclick="adjustStock(${newId}, -1)">➖</button>
        <span contenteditable="true" id="editableStock_${newId}" style="margin-left: 1px; margin: 0 5px;">1</span>
        <button type="button" class="stock-btn plus" onclick="adjustStock(${newId}, 1)">➕</button>
    </td>
    <td><input type="file" name="product_image[new]" accept="image/*" required></td>
    <td>
        <input type="hidden" name="new_product" value="1">
        <input type="hidden" id="name_${newId}" name="product_name">
        <input type="hidden" id="acronym_${newId}" name="acronym">
        <input type="hidden" id="price_${newId}" name="price">
        <input type="hidden" id="stocks_${newId}" name="stocks">
        <button type="submit" class="save-btn" onclick="syncRowInputs(${newId})">Save</button>
        <button type="button" class="remove-btn" onclick="this.closest('tr').remove()">Remove</button>
    </td>
    `;

    table.appendChild(row);
});

function syncRowInputs(id) {
    const name = document.getElementById(`editableName_${id}`).innerText.trim();
    const price = document.getElementById(`editablePrice_${id}`).innerText.trim();
    const stock = document.getElementById(`editableStock_${id}`).innerText.trim();
    const acronym = document.getElementById(`editableAcronym_${id}`).innerText.trim();

    document.getElementById(`name_${id}`).value = name;
    document.getElementById(`price_${id}`).value = price;
    document.getElementById(`stocks_${id}`).value = stock;
    document.getElementById(`acronym_${id}`).value = acronym;
}
</script>
</body>
</html>
