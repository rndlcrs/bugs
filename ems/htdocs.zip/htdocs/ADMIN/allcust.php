<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="allcus.css">
<title>CUSTOMER INFORMATION</title>
<body>
  
  <header>
 <div class="side-menu">
        <div class="brand-name">
            
        </div>

        <div class="title">
          <h3>CUSTOMER'S INFORMATION</h3>
        </div>
      

    <div>
        <div class="side-menu-user">
            <img src="../images/logo.png" alt="">
            <div>
                <h3>Kylie's Water Refilling Station</h3>
                <span><u>kylierefilling@gmail.com</u></span>
            </div>
        </div>
    </div>
        <ul>
            <li><a href="dashboard.php">DASHBOARD</a></li>
            <li><a href="allcust.php" >CUSTOMERS</a></li>
            <li><a href="allprods.php" >PRODUCTS</a></li>
            <li><a href="allorders.php" >ORDERS</a></li>
        </ul>
        </div>
    </div>
    
    <div class="wrapper">
        <h1>CUSTOMERS</h1>  
        <div class="log"><a href="/adminlogin.php">Logout</a></div>
    </div>

            <article>
<h2>Customers</h2><br>
       <?php
       $con = mysqli_connect("localhost","root","","kylies");//connect to database
       $result = mysqli_query($con,"SELECT * FROM kyliescustomers ");//query to get data from the table
       $data = $result->fetch_all(MYSQLI_ASSOC);//runs the query
       ?>
       
       <div class="scroll-table">
       <table border="1">
        <tr>
            <th>ID</th>
           <th>Username</th>
           <th>Email</th>
           <th>Address</th>
           <th>Mobile Number</th>
        </tr>

         <?php foreach($data as $row)://shows the data from the database into the table ?>
         <tr>
           <td><?= htmlspecialchars($row['ID']) ?></td>
           <td><?= htmlspecialchars($row['Username']) ?></td>
           <td><?= htmlspecialchars($row['Email']) ?></td>
           <td><?= htmlspecialchars($row['Address']) ?></td>
           <td><?= htmlspecialchars($row['MobileNumber']) ?></td>
         
         <?php endforeach ?>
       </table>
       </div>


         </article>
       </section>

</html>

</body>
