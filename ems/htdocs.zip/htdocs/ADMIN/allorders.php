<?php
session_start();
$con = mysqli_connect("localhost", "root", "", "kylies");

// Handle status update and notify customer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $orderId = intval($_POST['order_id']);
    $status = $_POST['status'];

    // Update order status
    $stmt = $con->prepare("UPDATE orders SET Status = ? WHERE ID = ?");
    $stmt->bind_param("si", $status, $orderId);
    $stmt->execute();

    // Fetch Username for notification
    $userResult = mysqli_query($con, "SELECT Username FROM orders WHERE ID = $orderId");
    $user = mysqli_fetch_assoc($userResult)['Username'];

    // Avoid duplicate notifications
    $checkNotif = mysqli_query($con, "SELECT * FROM notifcustomer WHERE Username = '$user' AND status = '$status' AND message LIKE '%$orderId%'");

    if (mysqli_num_rows($checkNotif) == 0) {
        $notifMessage = "Your order ID $orderId is now $status.";
        $insertNotif = $con->prepare("INSERT INTO notifcustomer (Username, message, status, CreatedAt, is_read) VALUES (?, ?, ?, NOW(), 0)");
        $insertNotif->bind_param("sss", $user, $notifMessage, $status);
        $insertNotif->execute();
    }

    header("Location: allorders.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="allorders.css">
  <title>ORDER INFORMATION</title>
</head>
<body>
  <header>
    <div class="side-menu">
      <div class="side-menu-user">
        <img src="../images/logo.png" alt="Logo">
        <div>
          <h3>Kylie's Water Refilling Station</h3>
          <span><u>kylierefilling@gmail.com</u></span>
        </div>
      </div>
      <ul>
        <li><a href="dashboard.php">DASHBOARD</a></li>
        <li><a href="allcust.php">CUSTOMERS</a></li>
        <li><a href="allprods.php">PRODUCTS</a></li>
        <li><a href="allorders.php" class="active">ORDERS</a></li>
      </ul>
    </div>

    <div class="wrapper">
      <h1>ORDERS</h1>
      <div class="log"><a href="/adminlogin.php">Logout</a></div>
    </div>
  </header>

  <main>
    <article>
      <h2>ORDERS</h2>
      <?php
        $result = mysqli_query($con, "SELECT * FROM orders ORDER BY ID DESC");
        $data = mysqli_fetch_all($result, MYSQLI_ASSOC);

        $productMap = [];
        $productRes = mysqli_query($con, "SELECT id, Acronym FROM products");
        while ($prod = mysqli_fetch_assoc($productRes)) {
            $productMap[$prod['id']] = $prod['Acronym'];
        }

      ?>

      <div class="scroll-table">
        <table border="1">
          <tr>
            
            <th>Full Name</th>
            <th>Address</th>
            <th>Payment Method</th>
            <th>Mobile Number</th>
            <th>Products</th>
            <th>Amount</th>
            <th>Delivery Date</th>
            <th>Order Date</th>
            <th>Status</th>
          </tr>

          <?php foreach ($data as $row): ?>
          <tr>
            
            <td><?= htmlspecialchars($row['FullName']) ?></td>
            <td><?= htmlspecialchars($row['Address']) ?></td>
            <td><?= htmlspecialchars($row['PaymentMethod']) ?></td>            
            <td><?= htmlspecialchars($row['MobileNumber']) ?></td>
            <td>
              <?php
                $cartItems = json_decode($row['Products'], true);
                $formatted = [];
                if (is_array($cartItems)) {
                    foreach ($cartItems as $item) {
                        $pid = $item['product_id'];
                        $qty = $item['quantity'];
                        $acronym = $productMap[$pid] ?? "ID#$pid";
                        $formatted[] = "$acronym x$qty";
                    }
                }
                echo htmlspecialchars(implode(', ', $formatted));
              ?>
            </td>
            <td><?= htmlspecialchars($row['Amount']) ?></td>
            <td><?= htmlspecialchars($row['DeliveryDate']) ?></td>
            <td><?= htmlspecialchars($row['OrderDate']) ?></td>
            <td>
              <form method="POST" style="margin:0;">
                <input type="hidden" name="order_id" value="<?= $row['ID'] ?>">
                <select name="status" onchange="this.form.submit()" class="status-dropdown">
                  <option value="Pending" <?= $row['status'] === 'Pending' ? 'selected' : '' ?>>Pending</option>
                  <option value="Processing" <?= $row['status'] === 'Processing' ? 'selected' : '' ?>>Processing</option>
                  <option value="On the way" <?= $row['status'] === 'On the way' ? 'selected' : '' ?>>On the way</option>
                  <option value="Delivered" <?= $row['status'] === 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                </select>
              </form>
            </td>
          </tr>
          <?php endforeach ?>
        </table>
      </div>
    </article>
  </main>
</body>
</html>
