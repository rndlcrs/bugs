<?php

// Insert new notifications for orders
$new_orders_result = mysqli_query($con, "SELECT ID, FullName, Amount FROM orders WHERE DATE(OrderDate) = '$today'");
while ($order = mysqli_fetch_assoc($new_orders_result)) {

    $id = $order['ID'];
    $FullName = $order['FullName'] ?? 'Unknown';
    $Amount = $order['Amount'];
    $message = "Order ID: $id | Customer: $FullName | Amount: ₱" . number_format($Amount, 2);

    $exists = mysqli_query($con, "SELECT 1 FROM notifications WHERE type='order' AND message='$message'");
    if (mysqli_num_rows($exists) == 0) {
        mysqli_query($con, "INSERT INTO notifications (type, message, is_read, created_at) VALUES ('order', '$message', 0, NOW())");
    }
}

// Insert new notifications for customers
$new_customers_result = mysqli_query($con, "SELECT ID, Username FROM kyliescustomers WHERE DATE(CreatedDate) = '$today'");
while ($cust = mysqli_fetch_assoc($new_customers_result)) {
    $Username = $cust['Username'] ?? 'Unknown';
    $message = "New customer: $Username";

    $exists = mysqli_query($con, "SELECT 1 FROM notifications WHERE type='customer' AND message='$message'");
    if (mysqli_num_rows($exists) == 0) {
        mysqli_query($con, "INSERT INTO notifications (type, message, is_read, created_at) VALUES ('customer', '$message', 0, NOW())");
    }
}

// Get unread notifications
$notif_query = "SELECT * FROM notifications WHERE created_at >= NOW() - INTERVAL 1 DAY ORDER BY created_at DESC";
$notif_result = mysqli_query($con, $notif_query);
$notifications = mysqli_fetch_all($notif_result, MYSQLI_ASSOC);
$has_unread = mysqli_num_rows(mysqli_query($con, "SELECT 1 FROM notifications WHERE is_read = 0 AND created_at >= NOW() - INTERVAL 1 DAY")) > 0;

$unread_result = mysqli_query($con, "SELECT COUNT(*) AS count FROM notifications WHERE is_read = 0 AND created_at >= NOW() - INTERVAL 1 DAY");
$notifData = mysqli_fetch_assoc($unread_result);
$initialUnread = (int)($notifData['count'] ?? 0);
?>