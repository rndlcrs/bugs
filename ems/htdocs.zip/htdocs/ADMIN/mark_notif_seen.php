<?php
$con = mysqli_connect("localhost", "root", "", "kylies");

if (!$con) {
    http_response_code(500);
    exit("DB connection failed.");
}

mysqli_query($con, "UPDATE notifications SET is_read = 1 WHERE is_read = 0 AND created_at >= NOW() - INTERVAL 1 DAY");echo "success";
?>
