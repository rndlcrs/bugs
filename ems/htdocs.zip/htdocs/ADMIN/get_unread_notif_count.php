<?php
$con = mysqli_connect("localhost", "root", "", "kylies");
$result = mysqli_query($con, "SELECT COUNT(*) AS count FROM notifications WHERE is_read = 0 AND created_at >= NOW() - INTERVAL 1 DAY");
$data = mysqli_fetch_assoc($result);
echo json_encode(['count' => (int)$data['count']]);
